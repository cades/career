Dictionary Web Extension
========================

a simple selection-to-lookup English dictionary web extension


## development

build extension

`npm run build`

watch & build

`npm run dev`

watch & build test code

`npm run tdd`

